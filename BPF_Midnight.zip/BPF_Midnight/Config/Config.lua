BPF_Config = BPF:NewModule("BPF_Config")

function BPF_Config:OnEnable()
    local options = {
        type = "group",
        args = {
            general = {
                name = "General",
                type = "group",
                order = 1,
                childGroups = "select",
                args = {
                    partyHeader = {
                        type = "header", name = "Party Frame Options", order = 1,
                    },
                    frame_alpha = {
                        type = "range", order = 2, min = 0.1, max = 1.0, step = 0.05,
                        isPercent = true,
                        name = "Frame Opacity",
                        desc = "Overall transparency of the party frames",
                        get  = function() return BPF_DB.frame_alpha end,
                        set  = function(_, v)
                            BPF_DB.frame_alpha = v
                            if BigPartyFrame then
                                BigPartyFrame:SetAlpha(v)
                            end
                        end,
                    },
                    range_check = {
                        type = "toggle", order = 3, width = "full",
                        name = "Dim Out-of-Range Members",
                        desc = "Dim party frames when a member is not visible/nearby. Uses visibility as a range proxy since Midnight restricts direct range checks.",
                        get  = function() return BPF_DB.range_check end,
                        set  = function(_, v)
                            BPF_DB.range_check = v
                            -- Reapply alpha to all frames immediately
                            if BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    if f:IsShown() then
                                        local baseAlpha = BPF_DB.frame_alpha or 1.0
                                        if not v then
                                            f:SetAlpha(baseAlpha)
                                        else
                                            local visible = UnitIsVisible(f.unitToken)
                                            f:SetAlpha(visible == false and baseAlpha * 0.3 or baseAlpha)
                                        end
                                    end
                                end
                            end
                        end,
                    },
                    use_class_portraits = {
                        type = "toggle", order = 4, width = "full",
                        name = "Use Class Portraits",
                        desc = "Show class icons instead of 3D portraits",
                        get  = function() return BPF_DB.use_class_portraits end,
                        set  = function(_, v)
                            BPF_DB.use_class_portraits = v
                            -- Refresh portraits on visible frames
                            if BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    if f:IsShown() then
                                        local function doPortrait(f)
                                            local _, class = UnitClass(f.unitToken)
                                            f:SetAttribute("bpf_class", class or "")
                                        end
                                        local ok = pcall(doPortrait, f)
                                        if ok then
                                            local class = f:GetAttribute("bpf_class") or ""
                                            if v and class ~= "" then
                                                local coords = CLASS_ICON_TCOORDS[class]
                                                if coords then
                                                    f.Portrait:SetTexture("Interface/TargetingFrame/UI-Classes-Circles")
                                                    f.Portrait:SetTexCoord(unpack(coords))
                                                end
                                            else
                                                SetPortraitTexture(f.Portrait, f.unitToken)
                                                f.Portrait:SetTexCoord(0,1,0,1)
                                            end
                                        end
                                    end
                                end
                            end
                        end,
                    },
                    use_class_color_healthbar = {
                        type = "toggle", order = 3, width = "full",
                        name = "Class Color Health Bar",
                        desc = "Color the health bar by class instead of HP percentage",
                        get  = function() return BPF_DB.use_class_color_healthbar end,
                        set  = function(_, v)
                            BPF_DB.use_class_color_healthbar = v
                            if BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    if f:IsShown() then
                                        local function readClass(f)
                                            local _, class = UnitClass(f.unitToken)
                                            f:SetAttribute("bpf_class", class or "")
                                        end
                                        securecall(readClass, f)
                                        local class = f:GetAttribute("bpf_class") or ""
                                        if v and class ~= "" then
                                            local cc = C_ClassColor.GetClassColor(class)
                                            if cc then
                                                f.HealthBar:SetStatusBarColor(cc.r, cc.g, cc.b)
                                            end
                                        else
                                            f.HealthBar:SetStatusBarColor(0.0, 0.8, 0.1)
                                        end
                                    end
                                end
                            end
                        end,
                    },
                    remove_realm_name = {
                        type = "toggle", order = 4, width = "full",
                        name = "Remove Realm From Name (*)",
                        desc = "Hide the realm suffix from player names",
                        get  = function() return BPF_DB.remove_realm_name end,
                        set  = function(_, v) BPF_DB.remove_realm_name = v end,
                    },
                    barHeader = {

                        type = "header", name = "Bar Textures", order = 9,
                    },
                    healthbar_texture = {
                        type = "select", order = 9.1, width = "full",
                        name = "Health Bar Texture",
                        dialogControl = "LSM30_Statusbar",
                        values = function()
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return {} end
                            local list = LSM:List(LSM.MediaType.STATUSBAR)
                            local out = {}
                            for _, name in ipairs(list) do out[name] = name end
                            return out
                        end,
                        get = function() return BPF_DB.healthbar_texture end,
                        set = function(_, v)
                            BPF_DB.healthbar_texture = v
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return end
                            local path = LSM:Fetch(LSM.MediaType.STATUSBAR, v)
                            if path and BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    if f.HealthBar then
                                        f.HealthBar:SetStatusBarTexture(path)
                                    end
                                end
                            end
                        end,
                    },
                    powerbar_texture = {
                        type = "select", order = 9.2, width = "full",
                        name = "Power Bar Texture",
                        dialogControl = "LSM30_Statusbar",
                        values = function()
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return {} end
                            local list = LSM:List(LSM.MediaType.STATUSBAR)
                            local out = {}
                            for _, name in ipairs(list) do out[name] = name end
                            return out
                        end,
                        get = function() return BPF_DB.powerbar_texture end,
                        set = function(_, v)
                            BPF_DB.powerbar_texture = v
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return end
                            local path = LSM:Fetch(LSM.MediaType.STATUSBAR, v)
                            if path and BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    if f.ManaBar then
                                        f.ManaBar:SetStatusBarTexture(path)
                                    end
                                end
                            end
                        end,
                    },
                    auraHeader = {
                        type = "header", name = "Aura Options", order = 10,
                    },
                    max_party_buffs = {
                        type = "range", order = 11, min = 3, max = 20, step = 1,
                        name = "Max Party Buffs (*)",
                        desc = "Maximum number of buff icons shown per member",
                        get  = function() return BPF_DB.max_party_buffs end,
                        set  = function(_, v) BPF_DB.max_party_buffs = v end,
                    },
                    max_party_debuffs = {
                        type = "range", order = 12, min = 3, max = 20, step = 1,
                        name = "Max Party Debuffs (*)",
                        desc = "Maximum number of debuff icons shown per member",
                        get  = function() return BPF_DB.max_party_debuffs end,
                        set  = function(_, v) BPF_DB.max_party_debuffs = v end,
                    },
                    reload_note = {
                        type = "description", order = 99,
                        name = "(*) Requires a UI reload to take effect.",
                    },
                },
            },

            font = {
                name = "Font & Layout",
                type = "group",
                order = 2,
                args = {
                    layoutHeader = {
                            type = "header", name = "Layout", order = 3.5,
                        },
                    hp_text_layout = {
                        type = "select", order = 4, width = "full",
                        name = "Health Bar Text Layout",
                        desc = "Alignment of text on the health bar. Split is only available when Format is set to Both.",
                        values = function()
                            local fmt = BPF_DB and BPF_DB.hp_text_format or "condensed"
                            if fmt == "both" then
                                return { ["center"]="Center", ["left"]="Left", ["right"]="Right", ["split"]="Split (pct left / value right)" }
                            else
                                return { ["center"]="Center", ["left"]="Left", ["right"]="Right" }
                            end
                        end,
                        sorting = function()
                            local fmt = BPF_DB and BPF_DB.hp_text_format or "condensed"
                            if fmt == "both" then
                                return { "center", "left", "right", "split" }
                            else
                                return { "center", "left", "right" }
                            end
                        end,
                        get = function()
                            local v = BPF_DB.hp_text_layout
                            local fmt = BPF_DB and BPF_DB.hp_text_format or "condensed"
                            -- If saved layout is "split" but format no longer supports it, fall back
                            if v == "split" and fmt ~= "both" then return "center" end
                            return v
                        end,
                        set = function(_, v)
                            BPF_DB.hp_text_layout = v
                            C_Timer.After(0, function()
                                if BigPartyFrame and BigPartyFrame.MemberFrames then
                                    for _, mf in ipairs(BigPartyFrame.MemberFrames) do
                                        BigPartyFrame.RefreshText(mf)
                                    end
                                end
                            end)
                        end,
                    },
                    power_text_layout = {
                        type = "select", order = 5, width = "full",
                        name = "Power Bar Text Layout",
                        desc = "Alignment of text on the power bar. Split is only available when Format is set to Both.",
                        values = function()
                            local fmt = BPF_DB and BPF_DB.power_text_format or "condensed"
                            if fmt == "both" then
                                return { ["center"]="Center", ["left"]="Left", ["right"]="Right", ["split"]="Split (pct left / value right)" }
                            else
                                return { ["center"]="Center", ["left"]="Left", ["right"]="Right" }
                            end
                        end,
                        sorting = function()
                            local fmt = BPF_DB and BPF_DB.power_text_format or "condensed"
                            if fmt == "both" then
                                return { "center", "left", "right", "split" }
                            else
                                return { "center", "left", "right" }
                            end
                        end,
                        get = function()
                            local v = BPF_DB.power_text_layout
                            local fmt = BPF_DB and BPF_DB.power_text_format or "condensed"
                            -- If saved layout is "split" but format no longer supports it, fall back
                            if v == "split" and fmt ~= "both" then return "center" end
                            return v
                        end,
                        set = function(_, v)
                            BPF_DB.power_text_layout = v
                            C_Timer.After(0, function()
                                if BigPartyFrame and BigPartyFrame.MemberFrames then
                                    for _, mf in ipairs(BigPartyFrame.MemberFrames) do
                                        BigPartyFrame.RefreshText(mf)
                                    end
                                end
                            end)
                        end,
                    },
                    hp_text_format = {
                        type = "select", order = 6, width = "full",
                        name = "Health Bar Text Format",
                        desc = "How health values are displayed on the health bar",
                        values = {
                            ["condensed"] = "Condensed  (251k / 251k)",
                            ["percent"]   = "Percentage  (100%)",
                            ["both"]      = "Both  (251k (100%))",
                            ["full"]      = "Full  (251838 / 251838)",
                        },
                        sorting = { "condensed", "percent", "both", "full" },
                        get = function() return BPF_DB.hp_text_format end,
                        set = function(_, v)
                            BPF_DB.hp_text_format = v
                            C_Timer.After(0, function()
                                if BigPartyFrame and BigPartyFrame.MemberFrames then
                                    for _, mf in ipairs(BigPartyFrame.MemberFrames) do
                                        BigPartyFrame.RefreshText(mf)
                                    end
                                end
                            end)
                        end,
                    },
                    power_text_format = {
                        type = "select", order = 7, width = "full",
                        name = "Power Bar Text Format",
                        desc = "How power/mana values are displayed on the power bar",
                        values = {
                            ["condensed"] = "Condensed  (251k / 251k)",
                            ["percent"]   = "Percentage  (100%)",
                            ["both"]      = "Both  (251k (100%))",
                            ["full"]      = "Full  (251838 / 251838)",
                        },
                        sorting = { "condensed", "percent", "both", "full" },
                        get = function() return BPF_DB.power_text_format end,
                        set = function(_, v)
                            BPF_DB.power_text_format = v
                            C_Timer.After(0, function()
                                if BigPartyFrame and BigPartyFrame.MemberFrames then
                                    for _, mf in ipairs(BigPartyFrame.MemberFrames) do
                                        BigPartyFrame.RefreshText(mf)
                                    end
                                end
                            end)
                        end,
                    },
                    fontHeader = {
                        type = "header", name = "Font", order = 0.5,
                    },
                    frame_font = {
                        type = "select", order = 1, width = "full",
                        name = "Font",
                        desc = "Font used for name, health and power text",
                        dialogControl = "LSM30_Font",
                        values = function()
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return {} end
                            local list = LSM:List(LSM.MediaType.FONT)
                            local out = {}
                            for _, name in ipairs(list) do out[name] = name end
                            return out
                        end,
                        get = function() return BPF_DB.frame_font end,
                        set = function(_, v)
                            BPF_DB.frame_font = v
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return end
                            local path = LSM:Fetch(LSM.MediaType.FONT, v)
                            local size    = BPF_DB.frame_font_size    or 10
                            local outline = BPF_DB.frame_font_outline or "OUTLINE"
                            if path and BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    f.Name:SetFont(path, size + 2, outline)
                                    if f.HealthText      then f.HealthText:SetFont(path, size, outline)      end
                                    if f.HealthTextLeft  then f.HealthTextLeft:SetFont(path, size, outline)  end
                                    if f.HealthTextRight then f.HealthTextRight:SetFont(path, size, outline) end
                                    if f.ManaText        then f.ManaText:SetFont(path, size, outline)        end
                                    if f.ManaTextLeft    then f.ManaTextLeft:SetFont(path, size, outline)    end
                                    if f.ManaTextRight   then f.ManaTextRight:SetFont(path, size, outline)   end
                                end
                            end
                        end,
                    },
                    frame_font_size = {
                        type = "range", order = 2, width = "full",
                        name = "Font Size",
                        desc = "Size of the text on the frames",
                        min = 6, max = 20, step = 1,
                        get = function() return BPF_DB.frame_font_size end,
                        set = function(_, v)
                            BPF_DB.frame_font_size = v
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return end
                            local path    = LSM:Fetch(LSM.MediaType.FONT, BPF_DB.frame_font or "Friz Quadrata TT")
                            local outline = BPF_DB.frame_font_outline or "OUTLINE"
                            if path and BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    f.Name:SetFont(path, v + 2, outline)
                                    if f.HealthText      then f.HealthText:SetFont(path, v, outline)      end
                                    if f.HealthTextLeft  then f.HealthTextLeft:SetFont(path, v, outline)  end
                                    if f.HealthTextRight then f.HealthTextRight:SetFont(path, v, outline) end
                                    if f.ManaText        then f.ManaText:SetFont(path, v, outline)        end
                                    if f.ManaTextLeft    then f.ManaTextLeft:SetFont(path, v, outline)    end
                                    if f.ManaTextRight   then f.ManaTextRight:SetFont(path, v, outline)   end
                                end
                            end
                        end,
                    },
                    frame_font_outline = {
                        type = "select", order = 3, width = "full",
                        name = "Font Outline",
                        desc = "Outline style for all frame text",
                        values = {
                            [""]              = "None",
                            ["OUTLINE"]       = "Outline",
                            ["THICKOUTLINE"]  = "Thick Outline",
                            ["MONOCHROME"]    = "Monochrome",
                        },
                        sorting = { "", "OUTLINE", "THICKOUTLINE", "MONOCHROME" },
                        get = function() return BPF_DB.frame_font_outline end,
                        set = function(_, v)
                            BPF_DB.frame_font_outline = v
                            local LSM = LibStub("LibSharedMedia-3.0", true)
                            if not LSM then return end
                            local path = LSM:Fetch(LSM.MediaType.FONT, BPF_DB.frame_font or "Friz Quadrata TT")
                            local size = BPF_DB.frame_font_size or 10
                            if path and BigPartyFrame and BigPartyFrame.MemberFrames then
                                for _, f in ipairs(BigPartyFrame.MemberFrames) do
                                    f.Name:SetFont(path, size + 2, v)
                                    if f.HealthText      then f.HealthText:SetFont(path, size, v)      end
                                    if f.HealthTextLeft  then f.HealthTextLeft:SetFont(path, size, v)  end
                                    if f.HealthTextRight then f.HealthTextRight:SetFont(path, size, v) end
                                    if f.ManaText        then f.ManaText:SetFont(path, size, v)        end
                                    if f.ManaTextLeft    then f.ManaTextLeft:SetFont(path, size, v)    end
                                    if f.ManaTextRight   then f.ManaTextRight:SetFont(path, size, v)   end
                                end
                            end
                        end,
                    },
                    },
                },
        },
    }

    LibStub("AceConfig-3.0"):RegisterOptionsTable("BPF Midnight", options)
    local panel = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("BPF Midnight")

    BPF:RegisterChatCommand("BPF", function()
        -- In Midnight, Settings.OpenToCategory expects a numeric categoryID.
        -- The panel frame has a .name property that is the numeric ID when
        -- registered via the new Settings API. Fall back to the panel's
        -- GetName() or open the general Settings window if all else fails.
        if Settings and Settings.OpenToCategory then
            local categoryID = panel and panel.name
            if type(categoryID) == "number" then
                Settings.OpenToCategory(categoryID)
            else
                -- Fallback: open the top-level Settings window
                Settings.OpenToCategory(nil)
            end
        end
    end)
end
