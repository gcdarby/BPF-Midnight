BPF = LibStub("AceAddon-3.0"):NewAddon("BPF", "AceConsole-3.0")

function BPF:OnInitialize()
    local defaults = {
        profile = {
            party = { x = 0, y = 0, point = "CENTER" },
            party_scale                = 1.0,
            use_class_portraits        = true,
            use_class_color_healthbar  = false,
            remove_realm_name          = true,
            max_party_buffs            = 10,
            max_party_debuffs          = 10,
            frame_alpha                = 1.0,
            range_check                = true,
            healthbar_texture          = "Blizzard",
            powerbar_texture           = "Blizzard",
            frame_font                 = "Friz Quadrata TT",
            frame_font_size            = 10,
            frame_font_outline         = "OUTLINE",
            text_format                = "condensed",
            hp_text_format             = "condensed",
            power_text_format          = "condensed",
            hp_text_layout             = "center",
            power_text_layout          = "center",
        }
    }
    self.db  = LibStub("AceDB-3.0"):New("BPFMidnightDB", defaults, true)
    BPF_DB   = self.db.profile
end

function BPF:OnEnable()
    -- Core event frame handles everything after PLAYER_LOGIN
end
