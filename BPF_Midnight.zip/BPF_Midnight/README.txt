Big Party Frames - Midnight Edition (v2.0)
==========================================

IMPORTANT: If you see errors mentioning "BigPartyMemberFrame.lua", WoW is
loading an old cached version. Follow ALL steps below carefully.

CLEAN INSTALL STEPS (do all of these):
---------------------------------------
1. Close WoW completely (not just the game, close the launcher too)

2. Delete the old addon folder:
   ...\World of Warcraft\_retail_\Interface\AddOns\BigPartyFrames\
   (Delete the ENTIRE folder, not just its contents)

3. Delete WoW's addon cache:
   ...\World of Warcraft\_retail_\Cache\
   (Delete the entire Cache folder — WoW will rebuild it)

4. Delete the saved variables:
   ...\World of Warcraft\_retail_\WTF\Account\<yourname>\SavedVariables\BPFDB.lua
   ...\World of Warcraft\_retail_\WTF\Account\<yourname>\SavedVariables\BPFDB.lua.bak

5. If using CurseForge/Wago/WoWUp addon manager:
   - Remove BigPartyFrames from the manager BEFORE installing manually
   - Addon managers keep their own copies and will reinstall the old version

6. Extract this zip to:
   ...\World of Warcraft\_retail_\Interface\AddOns\

7. Launch WoW and log in

8. If errors still appear, type /reload in-game

USAGE:
------
/BPF  - Opens the settings panel
