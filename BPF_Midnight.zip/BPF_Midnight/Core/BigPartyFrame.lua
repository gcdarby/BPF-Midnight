-- =============================================================================
-- Big Party Frames — Full Midnight (12.0) Rewrite
-- =============================================================================
-- Architecture:
--   • No UnitFrame_Initialize / UnitFrame_Update — these cannot be called from
--     addon-created frames in Midnight without tainting Blizzard's secure heal
--     prediction pipeline.
--   • All unit queries that return "secret values" (UnitHealth, UnitPower,
--     UnitInRange, UnitIsConnected, UnitIsDead, etc.) are read inside
--     securecall() closures and stored as plain numbers/strings in frame
--     attributes, which are never secret and safe to compare in addon code.
--   • Health / mana bars are plain StatusBar widgets driven entirely by
--     UNIT_HEALTH / UNIT_POWER events — no Blizzard bar infrastructure.
--   • Portraits use SetPortraitTexture / class icon coords.
--   • Layout mirrors the original: player-frame chrome, stacked vertically.
-- =============================================================================

local MAX_MEMBERS = MAX_PARTY_MEMBERS or 4

-- ---------------------------------------------------------------------------
-- Utility: run fn(…) in secure context, return results as plain values
-- ---------------------------------------------------------------------------
local function S(fn, ...)
    local ok, a, b, c, d = pcall(fn, ...)
    if ok then return a, b, c, d end
end

-- Per-frame state table: replaces SetAttribute/GetAttribute for combat-safe
-- storage of secret-derived values. SetAttribute on secure frames is blocked
-- during combat lockdown (ADDON_ACTION_BLOCKED), so we use plain Lua tables.
-- These are never secret and never restricted.
local frameState = {}  -- frameState[frame] = { key = value, ... }

local function SetState(f, key, value)
    if not frameState[f] then frameState[f] = {} end
    frameState[f][key] = value
end

local function GetState(f, key, default)
    local t = frameState[f]
    if t then
        local v = t[key]
        if v ~= nil then return v end
    end
    return default
end

-- ---------------------------------------------------------------------------
-- BPF namespace (set up by Config/Init.lua, referenced here)
-- ---------------------------------------------------------------------------
-- BPF and BPF_DB are globals created in Init.lua before Core loads.

-- ---------------------------------------------------------------------------
-- Member frame constructor
-- ---------------------------------------------------------------------------
local function CreateMemberFrame(parent, index)
    local unitToken = "party" .. index

    -- Root button — SecureUnitButtonTemplate gives us unit-based clicks/menus
    local f = CreateFrame("Button", "BPFMemberFrame" .. index, parent,
        "SecureUnitButtonTemplate, PingableUnitFrameTemplate")
    f:SetSize(232, 100)
    f:SetFrameStrata("LOW")
    f:RegisterForClicks("AnyUp")
    f:SetAttribute("type", "target")
    f:SetAttribute("unit", unitToken)
    f.index     = index
    f.unitToken = unitToken
    f.petToken  = "partypet" .. index

    -- Context menu
    f:SetAttribute("*type2", "togglemenu")
    local function openMenu(frame, unit)
        if UnitPopup_OpenMenu then
            UnitPopup_OpenMenu("PARTY", { unit = unit })
        end
    end
    SecureUnitButton_OnLoad(f, unitToken, openMenu)

    -- ── Chrome texture (player-frame art) ──────────────────────────────────
    local chrome = f:CreateTexture(nil, "ARTWORK")
    chrome:SetAtlas("UI-HUD-UnitFrame-Player-PortraitOn", true)
    chrome:SetPoint("CENTER")
    f.Chrome = chrome

    local vehicleChrome = f:CreateTexture(nil, "ARTWORK")
    vehicleChrome:SetAtlas("UI-HUD-UnitFrame-Player-PortraitOn-Vehicle", true)
    vehicleChrome:SetPoint("CENTER", -2, 0)
    vehicleChrome:Hide()
    f.VehicleChrome = vehicleChrome

    -- ── Portrait ───────────────────────────────────────────────────────────
    local portrait = f:CreateTexture(nil, "BACKGROUND")
    portrait:SetSize(60, 60)
    portrait:SetPoint("TOPLEFT", 24, -19)
    f.Portrait = portrait

    local portraitMask = f:CreateMaskTexture()
    portraitMask:SetAtlas("UI-HUD-UnitFrame-Player-Portrait-Mask")
    portraitMask:SetSize(60, 60)
    portraitMask:SetPoint("TOPLEFT", 24, -19)
    portrait:AddMaskTexture(portraitMask)

    -- ── Name ───────────────────────────────────────────────────────────────
    local name = f:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    name:SetSize(96, 12)
    name:SetPoint("TOPLEFT", 88, -27)
    name:SetJustifyH("LEFT")
    f.Name = name

    -- ── Health bar ─────────────────────────────────────────────────────────
    local hpBar = CreateFrame("StatusBar", nil, f)
    hpBar:SetSize(124, 19)
    hpBar:SetPoint("TOPLEFT", 85, -41)
    hpBar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    hpBar:SetStatusBarColor(0.1, 0.9, 0.1)
    hpBar:SetMinMaxValues(0, 1)
    hpBar:SetValue(1)
    f.HealthBar = hpBar

    local hpBg = hpBar:CreateTexture(nil, "BACKGROUND")
    hpBg:SetAllPoints()
    hpBg:SetColorTexture(0, 0, 0, 0.5)

    local hpText = hpBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hpText:SetPoint("CENTER")
    hpText:SetTextColor(1, 1, 1)
    f.HealthText = hpText

    -- Left/right text for split layout
    local hpLeft = hpBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hpLeft:SetPoint("LEFT", 2, 0)
    hpLeft:SetJustifyH("LEFT")
    hpLeft:SetTextColor(1, 1, 1)
    hpLeft:Hide()
    f.HealthTextLeft = hpLeft

    local hpRight = hpBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hpRight:SetPoint("RIGHT", -2, 0)
    hpRight:SetJustifyH("RIGHT")
    hpRight:SetTextColor(1, 1, 1)
    hpRight:Hide()
    f.HealthTextRight = hpRight

    -- ── Mana / power bar ───────────────────────────────────────────────────
    local mpBar = CreateFrame("StatusBar", nil, f)
    mpBar:SetSize(124, 10)
    mpBar:SetPoint("TOPLEFT", 85, -61)
    mpBar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    mpBar:SetStatusBarColor(0.0, 0.4, 1.0)
    mpBar:SetMinMaxValues(0, 1)
    mpBar:SetValue(1)
    f.ManaBar = mpBar

    local mpBg = mpBar:CreateTexture(nil, "BACKGROUND")
    mpBg:SetAllPoints()
    mpBg:SetColorTexture(0, 0, 0, 0.5)

    local mpText = mpBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    mpText:SetPoint("CENTER")
    mpText:SetTextColor(1, 1, 1)
    f.ManaText = mpText

    -- Left/right text for split layout
    local mpLeft = mpBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    mpLeft:SetPoint("LEFT", 2, 0)
    mpLeft:SetJustifyH("LEFT")
    mpLeft:SetTextColor(1, 1, 1)
    mpLeft:Hide()
    f.ManaTextLeft = mpLeft

    local mpRight = mpBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    mpRight:SetPoint("RIGHT", -2, 0)
    mpRight:SetJustifyH("RIGHT")
    mpRight:SetTextColor(1, 1, 1)
    mpRight:Hide()
    f.ManaTextRight = mpRight

    -- ── Combat flash overlay ────────────────────────────────────────────────
    local flash = f:CreateTexture(nil, "OVERLAY")
    flash:SetAtlas("UI-HUD-UnitFrame-Player-PortraitOn-InCombat", true)
    flash:SetPoint("CENTER", -1.5, 1)
    flash:Hide()
    f.Flash = flash

    -- ── Status flash (name area) ────────────────────────────────────────────
    local statusFlash = f:CreateTexture(nil, "OVERLAY")
    statusFlash:SetAtlas("UI-HUD-UnitFrame-Player-PortraitOn-Status", true)
    statusFlash:SetPoint("TOPLEFT", 17, -14)
    statusFlash:Hide()
    f.StatusFlash = statusFlash

    -- ── Overlay icons ───────────────────────────────────────────────────────
    local leaderIcon = f:CreateTexture(nil, "OVERLAY")
    leaderIcon:SetAtlas("UI-HUD-UnitFrame-Player-Group-LeaderIcon", true)
    leaderIcon:SetPoint("TOPLEFT", 86, -10)
    leaderIcon:Hide()
    f.LeaderIcon = leaderIcon

    local guideIcon = f:CreateTexture(nil, "OVERLAY")
    guideIcon:SetAtlas("UI-HUD-UnitFrame-Player-Group-GuideIcon", true)
    guideIcon:SetPoint("TOPLEFT", 86, -10)
    guideIcon:Hide()
    f.GuideIcon = guideIcon

    local pvpIcon = f:CreateTexture(nil, "OVERLAY")
    pvpIcon:SetSize(20, 20)
    pvpIcon:SetPoint("TOP", f, "TOPLEFT", 25, -50)
    pvpIcon:Hide()
    f.PVPIcon = pvpIcon

    local roleIcon = f:CreateTexture(nil, "OVERLAY")
    roleIcon:SetSize(12, 12)
    roleIcon:SetPoint("TOPLEFT", 196, -27)
    roleIcon:Hide()
    f.RoleIcon = roleIcon

    local cornerIcon = f:CreateTexture(nil, "OVERLAY")
    cornerIcon:SetAtlas("UI-HUD-UnitFrame-Player-PortraitOn-CornerEmbellishment", true)
    cornerIcon:SetPoint("TOPLEFT", 58.5, -53.5)
    f.CornerIcon = cornerIcon

    -- ── Disconnect icon ─────────────────────────────────────────────────────
    local dcIcon = f:CreateTexture(nil, "OVERLAY")
    dcIcon:SetSize(64, 64)
    dcIcon:SetTexture("Interface\\CharacterFrame\\Disconnect-Icon")
    dcIcon:SetPoint("LEFT", -7, -1)
    dcIcon:Hide()
    f.DisconnectIcon = dcIcon

    -- ── Not-present / summon / phase icon ───────────────────────────────────
    local npFrame = CreateFrame("Frame", nil, f)
    npFrame:SetSize(25, 25)
    npFrame:SetPoint("LEFT", f, "RIGHT", 2, -2)
    npFrame:SetIgnoreParentAlpha(true)
    npFrame:Hide()

    local npTex = npFrame:CreateTexture(nil, "ARTWORK")
    npTex:SetAllPoints()
    npFrame.texture = npTex

    local npBorder = npFrame:CreateTexture(nil, "OVERLAY")
    npBorder:SetTexture("Interface\\Common\\RingBorder")
    npBorder:SetAllPoints()
    npFrame.Border = npBorder

    npFrame:SetScript("OnEnter", function(self)
        if self.tooltip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.tooltip, nil, nil, nil, nil, true)
            GameTooltip:Show()
        end
    end)
    npFrame:SetScript("OnLeave", GameTooltip_Hide)
    f.NotPresentIcon = npFrame

    -- ── Ready check ─────────────────────────────────────────────────────────
    local rc = CreateFrame("Frame", nil, f, "ReadyCheckStatusTemplate")
    rc:SetSize(40, 40)
    rc:SetPoint("CENTER", portrait, "CENTER")
    rc:Hide()
    f.ReadyCheck = rc

    -- ── Resurrect indicator ──────────────────────────────────────────────────
    local resText = f:CreateFontString(nil, "ARTWORK", "ResurrectableIndicatorTemplate")
    resText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 44, 0)
    resText:Hide()
    f.ResurrectableIndicator = resText

    -- ── Tooltip passthrough ──────────────────────────────────────────────────
    f:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetUnit(self.unitToken)
        GameTooltip:Show()
    end)
    f:SetScript("OnLeave", GameTooltip_Hide)

    return f
end

-- ---------------------------------------------------------------------------
-- Update helpers — all unit queries via securecall + attribute bridge
-- ---------------------------------------------------------------------------

local powerColors = {
    [Enum.PowerType.Mana]        = {0.00, 0.40, 1.00},
    [Enum.PowerType.Rage]        = {1.00, 0.00, 0.00},
    [Enum.PowerType.Focus]       = {1.00, 0.50, 0.25},
    [Enum.PowerType.Energy]      = {1.00, 1.00, 0.00},
    [Enum.PowerType.RunicPower]  = {0.00, 0.82, 1.00},
    [Enum.PowerType.SoulShards]  = {0.50, 0.32, 0.55},
    [Enum.PowerType.LunarPower]  = {0.30, 0.52, 0.90},
    [Enum.PowerType.HolyPower]   = {0.95, 0.90, 0.60},
    [Enum.PowerType.Maelstrom]   = {0.00, 0.50, 1.00},
    [Enum.PowerType.Chi]         = {0.71, 1.00, 0.92},
    [Enum.PowerType.Insanity]    = {0.40, 0.00, 0.80},
    [Enum.PowerType.ArcaneCharges] = {0.10, 0.10, 0.98},
    [Enum.PowerType.Fury]        = {0.79, 0.26, 1.00},
    [Enum.PowerType.Pain]        = {1.00, 0.61, 0.00},
    [Enum.PowerType.Essence]     = {0.00, 0.80, 1.00},
}

local function GetPowerColor(powerType)
    local c = powerColors[powerType]
    if c then return c[1], c[2], c[3] end
    return 0.0, 0.4, 1.0
end

-- Helper: apply text to a bar respecting the layout setting.
-- layout "center"  -> single centered text element
-- layout "left"    -> single left-aligned text element
-- layout "right"   -> single right-aligned text element
-- layout "split"   -> pctText on left element, valText on right element
--                     (only valid when fmt="both"; callers must not pass "split" otherwise)
local function SetBarText(centerEl, leftEl, rightEl, pctText, valText, layout)
    layout = layout or "center"
    if layout == "split" then
        centerEl:Hide()
        leftEl:SetText(pctText or "")
        rightEl:SetText(valText or "")
        leftEl:Show()
        rightEl:Show()
    else
        leftEl:Hide()
        rightEl:Hide()
        centerEl:SetText(pctText or "")
        if layout == "left" then
            centerEl:SetPoint("LEFT", 2, 0)
            centerEl:SetJustifyH("LEFT")
        elseif layout == "right" then
            centerEl:SetPoint("RIGHT", -2, 0)
            centerEl:SetJustifyH("RIGHT")
        else -- "center"
            centerEl:SetPoint("CENTER")
            centerEl:SetJustifyH("CENTER")
        end
        centerEl:Show()
    end
end

local function UpdateHealth(f)
    local unit = f.unitToken
    -- In Midnight, UnitHealth() returns a secret value. The rules are:
    --   1. SetValue/SetMinMaxValues accept secret values directly (whitelisted).
    --   2. String concatenation (..) on secrets is allowed — produces a secret string,
    --      but SetText() accepts secret strings for display (whitelisted).
    --   3. Arithmetic and comparisons on secrets are NOT allowed.
    --   4. UnitHealthPercent() returns a secret value but can drive C_CurveUtil curves.
    -- So: drive the bar directly, display text via concatenation, use UnitPowerType
    -- (non-secret) for color decisions.

    -- Drive bar values directly — SetMinMaxValues/SetValue accept secrets
    f.HealthBar:SetMinMaxValues(0, UnitHealthMax(unit))
    f.HealthBar:SetValue(UnitHealth(unit))

    -- Health text
    if f.HealthText then
        if UnitIsDeadOrGhost(unit) then
            -- Dead: just show in center regardless of layout
            f.HealthTextLeft:Hide()
            f.HealthTextRight:Hide()
            f.HealthText:SetText(DEAD or "Dead")
            f.HealthText:Show()
        else
            local fmt      = BPF_DB and BPF_DB.hp_text_format  or "condensed"
            local hpLayout = BPF_DB and BPF_DB.hp_text_layout or "center"
            local pct = string.format("%.0f", UnitHealthPercent(unit, true, CurveConstants.ScaleTo100)) .. "%"
            -- For non-"both" formats: single text element, layout controls alignment.
            -- For "both": split shows pct left + value right; others show combined centered/left/right.
            if fmt == "percent" then
                SetBarText(f.HealthText, f.HealthTextLeft, f.HealthTextRight,
                    pct, nil, hpLayout)
            elseif fmt == "both" then
                if hpLayout == "split" then
                    SetBarText(f.HealthText, f.HealthTextLeft, f.HealthTextRight,
                        pct, AbbreviateNumbers(UnitHealth(unit)), "split")
                else
                    SetBarText(f.HealthText, f.HealthTextLeft, f.HealthTextRight,
                        AbbreviateNumbers(UnitHealth(unit)) .. " (" .. pct .. ")", nil, hpLayout)
                end
            elseif fmt == "full" then
                SetBarText(f.HealthText, f.HealthTextLeft, f.HealthTextRight,
                    UnitHealth(unit) .. " / " .. UnitHealthMax(unit), nil, hpLayout)
            else -- "condensed"
                SetBarText(f.HealthText, f.HealthTextLeft, f.HealthTextRight,
                    AbbreviateNumbers(UnitHealth(unit)) .. " / " .. AbbreviateNumbers(UnitHealthMax(unit)),
                    nil, hpLayout)
            end
        end
    end

    -- For bar color we need non-secret data. UnitClass returns plain strings.
    local _, class = UnitClass(unit)
    if BPF_DB and BPF_DB.use_class_color_healthbar and class then
        local cc = C_ClassColor.GetClassColor(class)
        if cc then
            f.HealthBar:SetStatusBarColor(cc.r, cc.g, cc.b)
        end
    else
        -- UnitHealthPercent returns a secret 0-100 value, but we can use
        -- GetValue/GetMinMaxValues on our own bar which returns plain numbers
        -- since we set them (they inherit the secret state though).
        -- Safest fallback: use a fixed green color, health percentage coloring
        -- requires secret arithmetic which isn't allowed.
        f.HealthBar:SetStatusBarColor(0.1, 0.9, 0.1)
    end
end

local function UpdatePower(f)
    local unit = f.unitToken
    -- Same pattern as health: SetMinMaxValues/SetValue accept secrets directly.
    -- UnitPowerType() is NOT secret — it returns a plain enum value.
    local powerType = UnitPowerType(unit)  -- plain, safe to store and compare

    f.ManaBar:SetMinMaxValues(0, UnitPowerMax(unit, powerType))
    f.ManaBar:SetValue(UnitPower(unit, powerType))

    -- Color from powerType which is a plain number — safe arithmetic
    local r, g, b = GetPowerColor(powerType)
    f.ManaBar:SetStatusBarColor(r, g, b)

    -- Power text
    if f.ManaText then
        local fmt    = BPF_DB and BPF_DB.power_text_format  or "condensed"
        local layout = BPF_DB and BPF_DB.power_text_layout or "centered"
        if fmt == "percent" then
            local function setPct(c, l, r, unit, pt, lay)
                local pct = string.format("%.0f", UnitPowerPercent(unit, pt, true, CurveConstants.ScaleTo100)) .. "%"
                SetBarText(c, l, r, pct, nil, lay)
            end
            securecall(setPct, f.ManaText, f.ManaTextLeft, f.ManaTextRight, unit, powerType, layout)
        elseif fmt == "both" then
            local function setBoth(c, l, r, unit, pt, lay)
                local pct = string.format("%.0f", UnitPowerPercent(unit, pt, true, CurveConstants.ScaleTo100)) .. "%"
                local val = AbbreviateNumbers(UnitPower(unit, pt))
                if lay == "split" then
                    SetBarText(c, l, r, pct, val, "split")
                else
                    SetBarText(c, l, r, val .. " (" .. pct .. ")", nil, lay)
                end
            end
            securecall(setBoth, f.ManaText, f.ManaTextLeft, f.ManaTextRight, unit, powerType, layout)
        elseif fmt == "full" then
            SetBarText(f.ManaText, f.ManaTextLeft, f.ManaTextRight,
                UnitPower(unit, powerType) .. " / " .. UnitPowerMax(unit, powerType),
                nil, layout)
        else -- "condensed"
            SetBarText(f.ManaText, f.ManaTextLeft, f.ManaTextRight,
                AbbreviateNumbers(UnitPower(unit, powerType)) .. " / " .. AbbreviateNumbers(UnitPowerMax(unit, powerType)),
                nil, layout)
        end
    end
end

local function UpdatePortrait(f)
    local unit = f.unitToken
    local function read(f)
        local _, class = UnitClass(unit)
        SetState(f, "bpf_class", class or "")
    end
    S(read, f)
    local class = GetState(f, "bpf_class") or ""

    if BPF_DB and BPF_DB.use_class_portraits and class ~= "" then
        local coords = CLASS_ICON_TCOORDS[class]
        if coords then
            f.Portrait:SetTexture("Interface/TargetingFrame/UI-Classes-Circles")
            f.Portrait:SetTexCoord(unpack(coords))
        end
    else
        SetPortraitTexture(f.Portrait, unit)
        f.Portrait:SetTexCoord(0, 1, 0, 1)
    end
end

local function UpdateName(f)
    local unit = f.unitToken
    local fullName = UnitName(unit) or ""
    if BPF_DB and BPF_DB.remove_realm_name then
        fullName = fullName:match("^([^%-]+)") or fullName
    end
    f.Name:SetText(fullName)
end

local function UpdateAlive(f)
    local unit = f.unitToken
    local function read(f)
        local dead  = UnitIsDead(unit)
        local ghost = UnitIsGhost(unit)
        SetState(f, "bpf_dead", dead  and 1 or 0)
        SetState(f, "bpf_ghost", ghost and 1 or 0)
    end
    S(read, f)

    local dead  = GetState(f, "bpf_dead")  == 1
    local ghost = GetState(f, "bpf_ghost") == 1

    if dead then
        f.Portrait:SetVertexColor(0.35, 0.35, 0.35, 1)
        f.HealthBar:SetStatusBarColor(0.35, 0.35, 0.35)
    elseif ghost then
        f.Portrait:SetVertexColor(0.2, 0.2, 0.75, 1)
    else
        f.Portrait:SetVertexColor(1, 1, 1, 1)
    end

    -- Resurrect indicator
    if PARTY_FRAME_RESURRECTABLE_TOOLTIP and f.ResurrectableIndicator then
        local function readRes(f)
            local playerDead = UnitIsDeadOrGhost("player")
            local unitDead   = UnitIsDeadOrGhost(unit)
            SetState(f, "bpf_showRes", (not playerDead and unitDead) and 1 or 0)
        end
        S(readRes, f)
        f.ResurrectableIndicator:SetShown(GetState(f, "bpf_showRes") == 1)
    end
end

local function UpdateRange(f)
    -- UnitInRange returns secret booleans in Midnight that cannot be
    -- compared in addon context without tainting. The approach here:
    --
    -- 1. Always default to fully visible (in-range).
    -- 2. Use UnitIsVisible() as a taint-free proxy — it returns a plain
    --    boolean and is not marked secret. A unit that is visible is
    --    always within rendering range (~300yd), which is a reasonable
    --    proxy for "in the same area". True spell-range checking is not
    --    possible without tainting in Midnight.
    -- 3. If BPF_DB.range_check is disabled by the user, always show full.
    if not (BPF_DB and BPF_DB.range_check) then
        f:SetAlpha((BPF_DB and BPF_DB.frame_alpha) or 1.0)
        return
    end

    local visible = UnitIsVisible(f.unitToken)
    local baseAlpha = (BPF_DB and BPF_DB.frame_alpha) or 1.0
    -- UnitIsVisible returns nil for non-existent units, treat as visible
    if visible == false then
        f:SetAlpha(baseAlpha * 0.3)
    else
        f:SetAlpha(baseAlpha)
    end
end

local function UpdateOnline(f)
    local unit = f.unitToken
    local function read(f)
        local connected = UnitIsConnected(unit)
        SetState(f, "bpf_connected", connected and 1 or 0)
    end
    S(read, f)

    local connected = GetState(f, "bpf_connected") == 1
    f.DisconnectIcon:SetShown(not connected)
    if not connected then
        f.HealthBar:SetStatusBarColor(0.5, 0.5, 0.5)
        SetDesaturation(f.Portrait, true)
    else
        SetDesaturation(f.Portrait, false)
    end
end

local function UpdateLeader(f)
    local function read(f)
        local isLeader = UnitIsGroupLeader(f.unitToken)
        local isGuide  = isLeader and HasLFGRestrictions()
        SetState(f, "bpf_leader", isLeader and 1 or 0)
        SetState(f, "bpf_guide", isGuide  and 1 or 0)
    end
    S(read, f)

    local leader = GetState(f, "bpf_leader") == 1
    local guide  = GetState(f, "bpf_guide")  == 1
    f.LeaderIcon:SetShown(leader and not guide)
    f.GuideIcon:SetShown(leader and guide)
end

local function UpdateRole(f)
    local role = UnitGroupRolesAssignedEnum(f.unitToken)
    if role == Enum.LFGRole.Tank then
        f.RoleIcon:SetAtlas("roleicon-tiny-tank"); f.RoleIcon:Show()
    elseif role == Enum.LFGRole.Healer then
        f.RoleIcon:SetAtlas("roleicon-tiny-healer"); f.RoleIcon:Show()
    elseif role == Enum.LFGRole.Damage then
        f.RoleIcon:SetAtlas("roleicon-tiny-dps"); f.RoleIcon:Show()
    else
        f.RoleIcon:Hide()
    end
end

local function UpdatePvP(f)
    local function read(f)
        local unit = f.unitToken
        if UnitIsPVPFreeForAll(unit) then
            SetState(f, "bpf_pvp", "ffa")
        else
            local fg = UnitFactionGroup(unit)
            if fg and fg ~= "Neutral" and UnitIsPVP(unit) then
                SetState(f, "bpf_pvp", fg)
            else
                SetState(f, "bpf_pvp", "none")
            end
        end
    end
    S(read, f)

    local pvp = GetState(f, "bpf_pvp") or "none"
    if pvp == "ffa" then
        f.PVPIcon:SetAtlas("ui-hud-unitframe-player-pvp-ffaicon", true); f.PVPIcon:Show()
    elseif pvp == "Horde" then
        f.PVPIcon:SetAtlas("ui-hud-unitframe-player-pvp-hordeicon", true); f.PVPIcon:Show()
    elseif pvp == "Alliance" then
        f.PVPIcon:SetAtlas("ui-hud-unitframe-player-pvp-allianceicon", true); f.PVPIcon:Show()
    else
        f.PVPIcon:Hide()
    end
end

local function UpdateNotPresent(f)
    local unit = f.unitToken
    local function read(f)
        if UnitInOtherParty(unit) then
            SetState(f, "bpf_np", "otherParty")
        elseif C_IncomingSummon.HasIncomingSummon(unit) then
            local st = C_IncomingSummon.IncomingSummonStatus(unit)
            if     st == Enum.SummonStatus.Pending  then SetState(f, "bpf_np", "summonPending")
            elseif st == Enum.SummonStatus.Accepted then SetState(f, "bpf_np", "summonAccepted")
            elseif st == Enum.SummonStatus.Declined then SetState(f, "bpf_np", "summonDeclined")
            else                                         SetState(f, "bpf_np", "none") end
        elseif UnitIsConnected(unit) and UnitPhaseReason(unit) then
            local reason = UnitPhaseReason(unit)
            SetState(f, "bpf_np", "phased")
            SetState(f, "bpf_phaseMsg", PartyUtil.GetPhasedReasonString(reason, unit) or "")
        else
            SetState(f, "bpf_np", "none")
        end
    end
    S(read, f)

    local np = GetState(f, "bpf_np") or "none"
    local ni = f.NotPresentIcon

    if np == "otherParty" then
        f:SetAlpha(0.6)
        ni.texture:SetAtlas("groupfinder-eye-single", true)
        ni.texture:SetTexCoord(0,1,0,1)
        ni.Border:Show()
        ni.tooltip = PARTY_IN_PUBLIC_GROUP_MESSAGE
        ni:Show()
    elseif np == "summonPending" then
        ni.texture:SetAtlas("Raid-Icon-SummonPending"); ni.texture:SetTexCoord(0,1,0,1)
        ni.tooltip = INCOMING_SUMMON_TOOLTIP_SUMMON_PENDING
        ni.Border:Hide(); ni:Show()
    elseif np == "summonAccepted" then
        ni.texture:SetAtlas("Raid-Icon-SummonAccepted"); ni.texture:SetTexCoord(0,1,0,1)
        ni.tooltip = INCOMING_SUMMON_TOOLTIP_SUMMON_ACCEPTED
        ni.Border:Hide(); ni:Show()
    elseif np == "summonDeclined" then
        ni.texture:SetAtlas("Raid-Icon-SummonDeclined"); ni.texture:SetTexCoord(0,1,0,1)
        ni.tooltip = INCOMING_SUMMON_TOOLTIP_SUMMON_DECLINED
        ni.Border:Hide(); ni:Show()
    elseif np == "phased" then
        f:SetAlpha(0.6)
        ni.texture:SetTexture("Interface\\TargetingFrame\\UI-PhasingIcon")
        ni.texture:SetTexCoord(0.15625, 0.84375, 0.15625, 0.84375)
        ni.Border:Hide()
        ni.tooltip = GetState(f, "bpf_phaseMsg") or ""
        ni:Show()
    else
        ni:Hide()
    end
end

local function UpdateReadyCheck(f)
    local rc     = f.ReadyCheck
    local status = GetReadyCheckStatus(f.unitToken)
    local function read(f)
        local hasName = UnitName(f.unitToken) ~= nil
        local online  = UnitIsConnected(f.unitToken)
        SetState(f, "bpf_rcOk", (hasName and online and status) and 1 or 0)
    end
    S(read, f)

    if GetState(f, "bpf_rcOk") == 1 then
        if status == "ready" then
            ReadyCheck_Confirm(rc, 1)
        elseif status == "notready" then
            ReadyCheck_Confirm(rc, 0)
        else
            ReadyCheck_Start(rc)
        end
        rc:Show()
    else
        rc:Hide()
    end
end

local function UpdateVehicle(f)
    local function read(f)
        local inVehicle = UnitHasVehicleUI(f.unitToken)
            and UnitIsConnected(f.unitToken)
        SetState(f, "bpf_vehicle", inVehicle and 1 or 0)
    end
    S(read, f)

    if GetState(f, "bpf_vehicle") == 1 then
        f.Chrome:Hide()
        f.VehicleChrome:Show()
    else
        f.Chrome:Show()
        f.VehicleChrome:Hide()
    end
end

local function UpdateExists(f)
    local function read(f)
        -- EditMode forces frames shown with "player" as stand-in
        if EditModeManagerFrame and EditModeManagerFrame:ArePartyFramesForcedShown()
            and not UnitExists(f.unitToken) then
            SetState(f, "bpf_exists", 1)
            SetState(f, "bpf_fakeUnit", 1)
        else
            SetState(f, "bpf_exists", UnitExists(f.unitToken) and 1 or 0)
            SetState(f, "bpf_fakeUnit", 0)
        end
    end
    S(read, f)
    return GetState(f, "bpf_exists") == 1
end

local function FullUpdate(f)
    local exists = UpdateExists(f)
    if not exists then
        f:Hide()
        return
    end
    f:Show()
    UpdateHealth(f)
    UpdatePower(f)
    UpdatePortrait(f)
    UpdateName(f)
    UpdateAlive(f)
    UpdateRange(f)
    UpdateOnline(f)
    UpdateLeader(f)
    UpdateRole(f)
    UpdatePvP(f)
    UpdateNotPresent(f)
    UpdateReadyCheck(f)
    UpdateVehicle(f)
end

-- ---------------------------------------------------------------------------
-- Aura frames
-- ---------------------------------------------------------------------------
local function CreateAuraButton(parent, name)
    local btn = CreateFrame("Button", name, parent)
    btn:SetSize(15, 15)
    btn:SetFrameLevel(7)

    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    btn.Icon = icon

    local cd = CreateFrame("Cooldown", name .. "CD", btn, "CooldownFrameTemplate")
    cd:SetAllPoints()
    cd:SetReverse(true)
    cd:SetHideCountdownNumbers(true)
    cd:SetFrameLevel(8)
    btn.Cooldown = cd

    local cdText = cd:CreateFontString(nil, "OVERLAY")
    cdText:SetFont(GameFontNormal:GetFont(), 6, "OUTLINE")
    cdText:SetTextColor(1,1,1)
    cdText:SetPoint("BOTTOM", icon, "CENTER", 0, -15)
    btn.CooldownText = cdText

    local countText = cd:CreateFontString(nil, "OVERLAY")
    countText:SetFont(GameFontNormal:GetFont(), 6, "OUTLINE")
    countText:SetTextColor(1,1,1)
    countText:SetPoint("CENTER", icon, "TOPRIGHT", 0, 0)
    btn.CountText = countText

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-Debuff-Overlays")
    border:SetSize(17,17)
    border:SetTexCoord(0.296875, 0.5703125, 0, 0.515625)
    border:SetPoint("TOPLEFT", -1, 1)
    btn.Border = border

    btn:SetScript("OnLeave", GameTooltip_Hide)
    return btn
end

local function SetupAuras(frames)
    local maxBuffs   = BPF_DB.max_party_buffs   or 10
    local maxDebuffs = BPF_DB.max_party_debuffs or 10

    for i = 1, MAX_MEMBERS do
        local f = frames[i]
        f.BuffButtons   = {}
        f.DebuffButtons = {}

        for j = 1, maxBuffs do
            local btn = CreateAuraButton(f, "BPFBuff"   .. i .. "_" .. j)
            if j == 1 then btn:SetPoint("RIGHT", f, "TOPRIGHT", 0, -35)
            else            btn:SetPoint("LEFT",  f.BuffButtons[j-1], "RIGHT", 4, 0) end
            btn:SetAttribute("unit", f.unitToken)
            RegisterUnitWatch(btn)
            f.BuffButtons[j] = btn
        end

        for j = 1, maxDebuffs do
            local btn = CreateAuraButton(f, "BPFDebuff" .. i .. "_" .. j)
            if j == 1 then btn:SetPoint("RIGHT", f, "BOTTOMRIGHT", 0, 35)
            else            btn:SetPoint("LEFT",  f.DebuffButtons[j-1], "RIGHT", 4, 0) end
            btn:SetAttribute("unit", f.unitToken)
            RegisterUnitWatch(btn)
            f.DebuffButtons[j] = btn
        end
    end
end

-- Build a sorted aura list for one filter ("HELPFUL" or "HARMFUL").
-- In combat, ALL fields of aura data are secret — including strings like
-- sourceUnit. tostring() de-taints numbers but NOT strings. The only safe
-- approach is to do all field access and comparisons inside securecall,
-- storing results as plain Lua literals (numbers/booleans we choose ourselves).
local function GetSortedAuras(unit, filter)
    local auras = {}
    local idx = 1
    -- We collect auraInstanceIDs first (these are plain integers, always safe)
    -- then fetch details inside securecall per aura.
    local instanceIDs = {}
    local data = C_UnitAuras.GetAuraDataByIndex(unit, idx, filter)
    while data do
        -- auraInstanceID is a plain integer, safe to store
        if data.auraInstanceID then
            table.insert(instanceIDs, {id = data.auraInstanceID, idx = idx})
        end
        idx = idx + 1
        data = C_UnitAuras.GetAuraDataByIndex(unit, idx, filter)
    end

    for _, entry in ipairs(instanceIDs) do
        local aura = {
            auraInstanceID = entry.id,
            auraIndex      = entry.idx,
            -- Defaults — overwritten inside securecall
            icon           = nil,
            count          = 0,
            duration       = 0,
            expires        = 0,
            isSelfCast     = false,  -- plain boolean, never secret
            valid          = false,
        }
        -- Extract all secret fields inside securecall.
        -- We convert them to plain values using these rules:
        -- string.format with %f/%d is whitelisted for secrets and produces
        -- a plain (non-secret) string. tonumber() on that plain string is safe.
        -- isSelfCast: compare sourceUnit inside securecall, store as plain bool.
        local function readNums(aura, unit, idx, filter)
            local d = C_UnitAuras.GetAuraDataByIndex(unit, idx, filter)
            if not d or not d.icon or type(d.icon) == "userdata" then return end
            aura.icon    = d.icon
            aura.valid   = true
            -- string.format with %f produces a plain (non-secret) string
            -- because format output is always a new plain string
            aura.expires  = tonumber(string.format("%f", d.expirationTime)) or 0
            aura.duration = tonumber(string.format("%f", d.duration))       or 0
            aura.count    = tonumber(string.format("%d", d.charges or 0))   or 0
            -- sourceUnit cannot be safely compared in combat (secret string,
            -- even string.format returns a secret string). Skip self-cast
            -- detection entirely — buff borders use neutral color instead.
            aura.isSelfCast = false
        end
        securecall(readNums, aura, unit, entry.idx, filter)

        if aura.valid then
            table.insert(auras, aura)
        end
    end

    -- Sort by expires ascending. These are now plain numbers — safe to compare.
    table.sort(auras, function(a, b)
        if a.expires == 0 then return false end
        if b.expires == 0 then return true end
        return a.expires < b.expires
    end)
    return auras
end

local function ApplyAuraToButton(btn, aura, unit, isDebuff)
    if not aura then
        btn:SetAlpha(0)
        CooldownFrame_Clear(btn.Cooldown)
        btn.CooldownText:SetText("")
        btn.CountText:SetText("")
        return
    end

    btn.Icon:SetTexture(aura.icon)
    btn:SetAlpha(1)

    -- These are plain numbers set by readNums via string.format/tonumber
    local expires  = aura.expires  or 0
    local duration = aura.duration or 0
    local count    = aura.count    or 0

    -- Cooldown frame: pass secret values directly to Blizzard's API.
    -- CooldownFrame_Set requires (startTime, duration) where startTime =
    -- expirationTime - duration — but that subtraction taints in combat.
    -- CooldownFrame_SetTimer takes (expirationTime, duration) directly
    -- and performs the subtraction internally in C, bypassing the secret rule.
    local function setCooldown(btn, unit, idx, filter)
        local d = C_UnitAuras.GetAuraDataByIndex(unit, idx, filter)
        if d and d.duration then
            if CooldownFrame_SetTimer then
                CooldownFrame_SetTimer(btn.Cooldown, d.expirationTime, d.duration, true)
            else
                -- Fallback: use SetCooldown which also accepts raw secret values
                btn.Cooldown:SetCooldown(d.expirationTime, d.duration)
            end
        end
    end
    securecall(setCooldown, btn, unit, aura.auraIndex,
        isDebuff and "HARMFUL" or "HELPFUL")

    -- Count text
    btn.CountText:SetText(count > 1 and count or "")

    -- Countdown text: compute from plain tonumber values, safe arithmetic
    local now = GetTime()  -- GetTime() is never secret
    local tl = expires > 0 and (expires - now) or 0
    if duration > 0 and tl > 0 then
        local ts
        if tl > 3600 then
            ts = math.floor(tl / 3600) .. "h"
        elseif tl > 60 then
            ts = math.floor(tl / 60) .. "m"
        else
            ts = tostring(math.floor(tl))
        end
        btn.CooldownText:SetText(ts)
    else
        btn.CooldownText:SetText("")
    end

    -- Border color: debuff = red, buff = white (self-cast green not possible
    -- in combat due to sourceUnit being a secret string in Midnight 12.0)
    if isDebuff then
        btn.Border:SetVertexColor(1, 0, 0)
    else
        btn.Border:SetVertexColor(1, 1, 1)
    end

    -- Tooltip
    local capturedUnit = unit
    local capturedID   = aura.auraInstanceID
    local capturedIdx  = aura.auraIndex
    local capturedFilter = isDebuff and "HARMFUL" or "HELPFUL"
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if capturedID and GameTooltip.SetUnitAuraByAuraInstanceID then
            GameTooltip:SetUnitAuraByAuraInstanceID(capturedUnit, capturedID)
        elseif isDebuff then
            GameTooltip:SetUnitDebuff(capturedUnit, capturedIdx)
        else
            GameTooltip:SetUnitBuff(capturedUnit, capturedIdx)
        end
        GameTooltip:Show()
    end)
end

local function UpdateAuras(frames)
    for i = 1, MAX_MEMBERS do
        local f = frames[i]
        if not f.BuffButtons then return end
        local unit = f.unitToken

        local buffs   = GetSortedAuras(unit, "HELPFUL")
        local debuffs = GetSortedAuras(unit, "HARMFUL")

        for j, btn in ipairs(f.BuffButtons) do
            ApplyAuraToButton(btn, buffs[j], unit, false)
        end
        for j, btn in ipairs(f.DebuffButtons) do
            ApplyAuraToButton(btn, debuffs[j], unit, true)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Main container frame + event dispatcher
-- ---------------------------------------------------------------------------
local container = CreateFrame("Frame", "BigPartyFrame", UIParent)
container:SetPoint("TOPLEFT")
container:SetSize(232, 100 * MAX_MEMBERS + 10 * (MAX_MEMBERS - 1))
container:SetFrameStrata("LOW")

local memberFrames = {}

-- Dummy names and classes shown in Edit Mode when not in a party
local inEditModePreview = false


local function LayoutFrames()
    for i, f in ipairs(memberFrames) do
        f:ClearAllPoints()
        if i == 1 then
            f:SetPoint("TOPLEFT", container, "TOPLEFT", 0, 0)
        else
            f:SetPoint("TOP", memberFrames[i-1], "BOTTOM", 0, -10)
        end
    end
    -- Resize container to fit visible frames
    local visible = 0
    for _, f in ipairs(memberFrames) do
        if f:IsShown() then visible = visible + 1 end
    end
    container:SetHeight(math.max(1, visible * 100 + (visible - 1) * 10))
end

local function ShouldShow()
    local function read(c)
        SetState(c, "bpf_shouldShow", (ShouldShowPartyFrames() or
             (EditModeManagerFrame and EditModeManagerFrame:ArePartyFramesForcedShown()))
            and 1 or 0)
    end
    S(read, container)
    return GetState(container, "bpf_shouldShow") == 1
end

local function UpdateAll()
    for _, f in ipairs(memberFrames) do
        FullUpdate(f)
    end
    LayoutFrames()
end

-- Aura throttle
local auraTimer = 0
local AURA_THROTTLE = 0.1

container:SetScript("OnUpdate", function(self, elapsed)
    auraTimer = auraTimer + elapsed
    if auraTimer >= AURA_THROTTLE then
        if #memberFrames > 0 and memberFrames[1].BuffButtons then
            UpdateAuras(memberFrames)
        end
        auraTimer = 0
    end
end)

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("UNIT_HEALTH")
eventFrame:RegisterEvent("UNIT_MAXHEALTH")
eventFrame:RegisterEvent("UNIT_POWER_UPDATE")
eventFrame:RegisterEvent("UNIT_MAXPOWER")
eventFrame:RegisterEvent("UNIT_POWER_BAR_SHOW")
eventFrame:RegisterEvent("UNIT_POWER_BAR_HIDE")
eventFrame:RegisterEvent("UNIT_PORTRAIT_UPDATE")
eventFrame:RegisterEvent("UNIT_NAME_UPDATE")
eventFrame:RegisterEvent("UNIT_AURA")
eventFrame:RegisterEvent("UNIT_CONNECTION")
eventFrame:RegisterEvent("UNIT_PHASE")
eventFrame:RegisterEvent("UNIT_FLAGS")
eventFrame:RegisterEvent("UNIT_FACTION")
eventFrame:RegisterEvent("UNIT_ENTERED_VEHICLE")
eventFrame:RegisterEvent("UNIT_EXITED_VEHICLE")
eventFrame:RegisterEvent("UNIT_OTHER_PARTY_CHANGED")
eventFrame:RegisterEvent("PARTY_LEADER_CHANGED")
eventFrame:RegisterEvent("PARTY_LOOT_METHOD_CHANGED")
eventFrame:RegisterEvent("PARTY_MEMBER_ENABLE")
eventFrame:RegisterEvent("PARTY_MEMBER_DISABLE")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("READY_CHECK")
eventFrame:RegisterEvent("READY_CHECK_CONFIRM")
eventFrame:RegisterEvent("READY_CHECK_FINISHED")
eventFrame:RegisterEvent("INCOMING_SUMMON_CHANGED")
eventFrame:RegisterEvent("UPDATE_ACTIVE_BATTLEFIELD")
eventFrame:RegisterEvent("VARIABLES_LOADED")

eventFrame:SetScript("OnEvent", function(self, event, arg1, ...)
    if event == "PLAYER_LOGIN" then
        -- Build frames now that all globals are available
        for i = 1, MAX_MEMBERS do
            memberFrames[i] = CreateMemberFrame(container, i)
        end
        -- Position container from saved DB
        if BPF_DB and BPF_DB.party then
            container:ClearAllPoints()
            container:SetPoint(BPF_DB.party.point or "CENTER",
                               BPF_DB.party.x     or 0,
                               BPF_DB.party.y     or 0)
        end
        -- Apply saved opacity
        container:SetAlpha(BPF_DB and BPF_DB.frame_alpha or 1.0)
        -- Apply saved bar textures and fonts
        local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
        if LSM then
            local hpTex = LSM:Fetch(LSM.MediaType.STATUSBAR,
                BPF_DB and BPF_DB.healthbar_texture or "Blizzard")
            local mpTex = LSM:Fetch(LSM.MediaType.STATUSBAR,
                BPF_DB and BPF_DB.powerbar_texture or "Blizzard")
            local fontPath  = LSM:Fetch(LSM.MediaType.FONT,
                BPF_DB and BPF_DB.frame_font or "Friz Quadrata TT")
            local fontSize   = BPF_DB and BPF_DB.frame_font_size    or 10
            local fontOutline = BPF_DB and BPF_DB.frame_font_outline or "OUTLINE"
            for _, f in ipairs(memberFrames) do
                if hpTex then f.HealthBar:SetStatusBarTexture(hpTex) end
                if mpTex then f.ManaBar:SetStatusBarTexture(mpTex) end
                if fontPath then
                    f.Name:SetFont(fontPath, fontSize + 2, fontOutline)
                    if f.HealthText      then f.HealthText:SetFont(fontPath, fontSize, fontOutline)      end
                    if f.HealthTextLeft  then f.HealthTextLeft:SetFont(fontPath, fontSize, fontOutline)  end
                    if f.HealthTextRight then f.HealthTextRight:SetFont(fontPath, fontSize, fontOutline) end
                    if f.ManaText        then f.ManaText:SetFont(fontPath, fontSize, fontOutline)        end
                    if f.ManaTextLeft    then f.ManaTextLeft:SetFont(fontPath, fontSize, fontOutline)    end
                    if f.ManaTextRight   then f.ManaTextRight:SetFont(fontPath, fontSize, fontOutline)   end
                end
            end
        end
        SetupAuras(memberFrames)
        UpdateAll()
        container:SetShown(ShouldShow())

        -- Hide Blizzard's default party frame
        if PartyFrame and PartyFrame.Hide then
            PartyFrame:Hide()
        end

        -- EditMode integration
        local LEM = LibStub and LibStub("LibEditMode", true)
        if LEM then
            local function onPos(frame, layoutName, point, x, y)
                BPF_DB.party = BPF_DB.party or {}
                BPF_DB.party.point = point
                BPF_DB.party.x = x
                BPF_DB.party.y = y
            end
            LEM:AddFrame(container, onPos, BPF_DB.party)

            -- Add a Scale slider to the Edit Mode dialog
            LEM:AddFrameSettings(container, {
                {
                    kind     = LEM.SettingType.Slider,
                    name     = "Scale",
                    default  = 1.0,
                    minValue = 0.5,
                    maxValue = 2.0,
                    valueStep = 0.05,
                    formatter = function(value)
                        return string.format("%.0f%%", value * 100)
                    end,
                    get = function(layoutName)
                        return BPF_DB.party_scale or 1.0
                    end,
                    set = function(layoutName, value)
                        BPF_DB.party_scale = value
                        container:SetScale(value)
                    end,
                },
            })

            -- Apply saved scale
            container:SetScale(BPF_DB.party_scale or 1.0)

            LEM:RegisterCallback("enter", function()
                -- Always show the container in Edit Mode at full party size
                -- so it's visible and grabbable even when not in a party
                inEditModePreview = true
                container:SetSize(232, MAX_MEMBERS * 100 + (MAX_MEMBERS - 1) * 10)
                container:Show()
            end)
            LEM:RegisterCallback("exit", function()
                inEditModePreview = false
                UpdateAll()
                container:SetShown(ShouldShow())
            end)
            LEM:RegisterCallback("layout", function()
                container:ClearAllPoints()
                container:SetPoint(
                    BPF_DB.party and BPF_DB.party.point or "CENTER",
                    BPF_DB.party and BPF_DB.party.x     or 0,
                    BPF_DB.party and BPF_DB.party.y     or 0)
                -- Reapply scale on layout change
                container:SetScale(BPF_DB.party_scale or 1.0)
            end)
        end
        return
    end

    if #memberFrames == 0 then return end

    if event == "GROUP_ROSTER_UPDATE"
    or event == "UPDATE_ACTIVE_BATTLEFIELD"
    or event == "PLAYER_ENTERING_WORLD"
    or event == "VARIABLES_LOADED" then
        UpdateAll()
        container:SetShown(ShouldShow())

    elseif event == "UNIT_HEALTH" or event == "UNIT_MAXHEALTH" then
        for _, f in ipairs(memberFrames) do
            if arg1 == f.unitToken then
                UpdateHealth(f)
                UpdateAlive(f)
            end
        end

    elseif event == "UNIT_POWER_UPDATE" or event == "UNIT_MAXPOWER"
        or event == "UNIT_POWER_BAR_SHOW" or event == "UNIT_POWER_BAR_HIDE" then
        for _, f in ipairs(memberFrames) do
            if arg1 == f.unitToken then UpdatePower(f) end
        end

    elseif event == "UNIT_PORTRAIT_UPDATE" then
        for _, f in ipairs(memberFrames) do
            if arg1 == f.unitToken then UpdatePortrait(f) end
        end

    elseif event == "UNIT_NAME_UPDATE" then
        for _, f in ipairs(memberFrames) do
            if arg1 == f.unitToken then UpdateName(f) end
        end

    elseif event == "UNIT_CONNECTION" then
        for _, f in ipairs(memberFrames) do
            if arg1 == f.unitToken then
                UpdateOnline(f)
                UpdateNotPresent(f)
            end
        end

    elseif event == "UNIT_PHASE" or event == "UNIT_FLAGS"
        or event == "UNIT_OTHER_PARTY_CHANGED"
        or event == "INCOMING_SUMMON_CHANGED"
        or event == "PARTY_MEMBER_ENABLE"
        or event == "PARTY_MEMBER_DISABLE" then
        for _, f in ipairs(memberFrames) do
            if not arg1 or arg1 == f.unitToken or event == "INCOMING_SUMMON_CHANGED"
                or event == "PARTY_MEMBER_ENABLE" or event == "PARTY_MEMBER_DISABLE" then
                UpdateNotPresent(f)
                UpdateRange(f)
            end
        end

    elseif event == "UNIT_FACTION" then
        for _, f in ipairs(memberFrames) do
            if arg1 == f.unitToken then UpdatePvP(f) end
        end

    elseif event == "UNIT_ENTERED_VEHICLE" or event == "UNIT_EXITED_VEHICLE" then
        for _, f in ipairs(memberFrames) do
            if arg1 == f.unitToken then UpdateVehicle(f) end
        end

    elseif event == "PARTY_LEADER_CHANGED" or event == "PARTY_LOOT_METHOD_CHANGED" then
        for _, f in ipairs(memberFrames) do UpdateLeader(f) end

    elseif event == "READY_CHECK" or event == "READY_CHECK_CONFIRM" then
        for _, f in ipairs(memberFrames) do UpdateReadyCheck(f) end

    elseif event == "READY_CHECK_FINISHED" then
        for _, f in ipairs(memberFrames) do
            local function doFinish(f)
                if UnitExists(f.unitToken) then
                    ReadyCheck_Finish(f.ReadyCheck, DEFAULT_READY_CHECK_STAY_TIME)
                end
            end
            S(doFinish, f)
        end

    elseif event == "UNIT_AURA" then
        -- Handled by OnUpdate throttle
    end
end)

-- Expose container as BigPartyFrame global for Config compatibility
BigPartyFrame = container
BigPartyFrame.MemberFrames = memberFrames

-- Expose a text refresh function for Config to call when layout changes
BigPartyFrame.RefreshText = function(f)
    if f and f:IsShown() and f.unitToken then
        UpdateHealth(f)
        UpdatePower(f)
    end
end
