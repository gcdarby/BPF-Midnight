-- AceGUI-3.0 SharedMediaWidgets
-- Provides "LSM30_Statusbar" widget type for AceConfig dropdowns

local AceGUI = LibStub("AceGUI-3.0")
local LSM    = LibStub("LibSharedMedia-3.0")

if not AceGUI or not LSM then return end

local function Constructor()
    local self = AceGUI:Create("Dropdown")
    self.type = "LSM30_Statusbar"

    local function Populate(self)
        local list = LSM:List(LSM.MediaType.STATUSBAR)
        local values = {}
        for _, name in ipairs(list) do
            values[name] = name
        end
        self:SetList(values, list)
    end

    local origOpen = self.OpenDropdown
    self.OpenDropdown = function(self2, ...)
        Populate(self2)
        origOpen(self2, ...)
    end

    Populate(self)
    return self
end

AceGUI:RegisterWidgetType("LSM30_Statusbar", Constructor, 1)

-- Font widget
local function FontConstructor()
    local self = AceGUI:Create("Dropdown")
    self.type = "LSM30_Font"

    local function Populate(self)
        local list = LSM:List(LSM.MediaType.FONT)
        local values = {}
        for _, name in ipairs(list) do
            values[name] = name
        end
        self:SetList(values, list)
    end

    local origOpen = self.OpenDropdown
    self.OpenDropdown = function(self2, ...)
        Populate(self2)
        origOpen(self2, ...)
    end

    Populate(self)
    return self
end

AceGUI:RegisterWidgetType("LSM30_Font", FontConstructor, 1)
