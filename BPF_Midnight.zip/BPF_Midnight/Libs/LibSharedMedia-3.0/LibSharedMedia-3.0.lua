-- LibSharedMedia-3.0 minimal implementation
-- Provides a registry of shared media (statusbar textures, fonts, etc.)
-- Compatible with the full LSM API so other addons can register their textures too.

local MAJOR, MINOR = "LibSharedMedia-3.0", 8
local lib = LibStub:NewLibrary(MAJOR, MINOR)
if not lib then return end

lib.MediaType = lib.MediaType or {}
lib.MediaType.STATUSBAR = "statusbar"
lib.MediaType.BORDER     = "border"
lib.MediaType.BACKGROUND = "background"
lib.MediaType.FONT       = "font"
lib.MediaType.SOUND      = "sound"

lib.DefaultMedia = lib.DefaultMedia or {}
lib.MediaTable   = lib.MediaTable   or {}
lib.callbacks    = lib.callbacks    or LibStub("CallbackHandler-1.0"):New(lib)

local mt = { __index = function(t, k) return false end }
lib.MediaTable.statusbar = lib.MediaTable.statusbar or setmetatable({}, mt)

local function CopyTable(src, dest)
    dest = dest or {}
    for k,v in pairs(src) do dest[k] = v end
    return dest
end

-- Built-in statusbar textures (paths included with WoW client)
local DEFAULT_STATUSBARS = {
    ["Blizzard"]            = "Interface\\TargetingFrame\\UI-StatusBar",
    ["Blizzard Raid Bar"]   = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
    ["Smooth"]              = "Interface\\AddOns\\BPF_Midnight\\Media\\Smooth",
    ["Flat"]                = "Interface\\Buttons\\WHITE8X8",
    ["Armory"]              = "Interface\\Addons\\Blizzard_TimeManager\\UI-Stopwatch-Bar",
    ["BantoBar"]            = "Interface\\Addons\\Blizzard_AchievementUI\\UI-Achievement-WoodBorder",
    ["Gradient"]            = "Interface\\PaperDollInfoFrame\\UI-Character-Skills-Bar",
    ["Otravi"]              = "Interface\\CastingBar\\UI-CastingBar-Border",
    ["Perl"]                = "Interface\\TargetingFrame\\UI-StatusBar",
    ["Minimalist"]          = "Interface\\Buttons\\WHITE8X8",
    ["LiteStep"]            = "Interface\\Buttons\\WHITE8X8",
}

-- Register all defaults if not already registered
for name, path in pairs(DEFAULT_STATUSBARS) do
    if not lib.MediaTable.statusbar[name] then
        lib.MediaTable.statusbar[name] = path
    end
end

lib.DefaultMedia.statusbar = lib.DefaultMedia.statusbar or "Blizzard"

-- Built-in WoW fonts
lib.MediaTable.font = lib.MediaTable.font or setmetatable({}, mt)
local DEFAULT_FONTS = {
    ["Friz Quadrata TT"]  = "Fonts\\FRIZQT__.TTF",
    ["Arial Narrow"]      = "Fonts\\ARIALN.TTF",
    ["Morpheus"]          = "Fonts\\MORPHEUS.TTF",
    ["Skurri"]            = "Fonts\\SKURRI.TTF",
    ["Accidental Presidency"] = "Fonts\\bROKENn.ttf",
    ["PT Sans Narrow"]    = "Fonts\\PTSansNarrow.ttf",
}
for name, path in pairs(DEFAULT_FONTS) do
    if not lib.MediaTable.font[name] then
        lib.MediaTable.font[name] = path
    end
end
lib.DefaultMedia.font = lib.DefaultMedia.font or "Friz Quadrata TT"

function lib:Register(mediatype, key, data)
    if not lib.MediaTable[mediatype] then
        lib.MediaTable[mediatype] = setmetatable({}, mt)
    end
    lib.MediaTable[mediatype][key] = data
    lib.callbacks:Fire("LibSharedMedia_Registered", mediatype, key)
end

function lib:Fetch(mediatype, key, noDefault)
    local mtt = lib.MediaTable[mediatype]
    if mtt then
        local found = mtt[key]
        if found then return found end
    end
    if not noDefault then
        return lib:GetDefault(mediatype)
    end
end

function lib:GetDefault(mediatype)
    local defaultKey = lib.DefaultMedia[mediatype]
    if defaultKey then
        return lib.MediaTable[mediatype] and lib.MediaTable[mediatype][defaultKey]
    end
end

function lib:SetDefault(mediatype, key)
    lib.DefaultMedia[mediatype] = key
end

function lib:IsValid(mediatype, key)
    return lib.MediaTable[mediatype] and lib.MediaTable[mediatype][key] ~= nil
end

function lib:HashTable(mediatype)
    return lib.MediaTable[mediatype]
end

function lib:List(mediatype)
    if not lib.MediaTable[mediatype] then return end
    local out = {}
    for k in pairs(lib.MediaTable[mediatype]) do
        out[#out+1] = k
    end
    table.sort(out)
    return out
end
